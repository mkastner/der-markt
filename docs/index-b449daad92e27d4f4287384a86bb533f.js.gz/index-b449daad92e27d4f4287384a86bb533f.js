
//# sourceMappingURL=https://www.der-markt.com/index.js.map